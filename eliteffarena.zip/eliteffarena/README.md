# EliteFFArena 🔥

Free Fire tournament registration platform with **WhatsApp-based payment verification**.
Players register on the website → pay via UPI → send screenshot on WhatsApp → admin approves → slot confirmed + room ID/password sent automatically on WhatsApp.

---

## ⚠️ Important reality-check (read before going live)

This project gives you a **manual/semi-automatic** payment verification flow (admin checks the screenshot, then approves). It does **NOT** do automatic, legally-compliant real-money payment processing. Before running this for real tournaments with real money, please understand:

1. **No payment gateway is integrated.** You collect money via your own personal/business UPI ID and verify proof manually. This is how most small/medium FF tournament organizers in India currently operate, but it means there's no automated fraud protection (fake/edited screenshots are possible — always cross-check the UTR/transaction reference where possible).
2. **WhatsApp Business API (Meta Cloud API) requires a Meta Developer account.** Using your personal WhatsApp number with automation scripts violates WhatsApp's Terms of Service and can get the number banned. This project is built specifically for the official Cloud API.
3. **Real-money online gaming has state-specific legal considerations in India.** Rules differ by state (some restrict real-money gaming formats). Please check applicable regulations for your state/audience before charging entry fees at scale.
4. **You are responsible for refund policy, dispute handling, and data protection** (player UIDs, phone numbers, payment screenshots are personal data — store and handle them responsibly).

---

## What's included

- **Public website**: Home, tournament listing/filters, tournament detail, registration form (solo/duo/squad with dynamic team member fields), registration success/closed states, leaderboard/results page.
- **Admin panel**: Login, dashboard with stats, full tournament CRUD, registration review queue (approve/reject with reason), room ID/password publishing (auto-notifies confirmed teams via WhatsApp), results entry, WhatsApp message audit log.
- **WhatsApp bot** (Meta Cloud API): Receives payment screenshots, auto-matches them to the player's pending registration by phone number, sends auto-replies, and sends approval/rejection/room-detail messages triggered from the admin panel.
- **Database**: MongoDB via Mongoose (Tournament, Registration, Admin, WhatsappLog models).

---

## 1. Prerequisites

- [Node.js](https://nodejs.org/) v18 or higher
- A MongoDB database — easiest option is a **free MongoDB Atlas cluster**: https://www.mongodb.com/atlas (or run MongoDB locally if you prefer)
- A **Meta Developer account** for the WhatsApp Cloud API (free) — see Section 4 below
- A server/hosting to deploy on (Section 6) — for local testing, your own machine works fine

---

## 2. Local Setup

```bash
# 1. Go into the project folder
cd eliteffarena

# 2. Install dependencies
npm install

# 3. Copy the example environment file and fill in your values
cp .env.example .env
# now open .env in any editor and fill in MONGODB_URI, SESSION_SECRET, WHATSAPP_* etc.

# 4. Create your first admin login
#    (uses ADMIN_USERNAME / ADMIN_PASSWORD from your .env)
npm run seed-admin

# 5. Start the server
npm start
# or, for auto-restart on file changes during development:
npm run dev
```

Visit:
- Website → `http://localhost:3000`
- Admin panel → `http://localhost:3000/admin/login`

---

## 3. Creating your first tournament

1. Log into `/admin/login` with the username/password you set in `.env` (the ones used by `npm run seed-admin`).
2. Go to **Tournaments → + New Tournament**.
3. Fill in title, mode (Solo/Duo/Squad), entry fee, prize pool, max slots, match date, registration deadline.
4. Save — it will now appear on the public site (if status is "registration_open").

---

## 4. Setting up the WhatsApp Bot (Meta Cloud API)

This is the part that needs the most care. Follow these steps exactly:

### Step 1 — Create a Meta App
1. Go to https://developers.facebook.com/ and log in / sign up.
2. Click **My Apps → Create App**. Choose type **"Business"**.
3. Once created, from the app dashboard, click **Add Product** and add **WhatsApp**.

### Step 2 — Get your test credentials
1. Inside the WhatsApp product, go to **API Setup**.
2. You'll see a **temporary access token** (valid 24 hours — fine for testing) and a **Phone Number ID** (Meta gives you a free test number to start).
3. Copy these into your `.env`:
   ```
   WHATSAPP_TOKEN=<the temporary access token>
   WHATSAPP_PHONE_NUMBER_ID=<the phone number id>
   ```
4. On the same page, add your **own WhatsApp number** as a "recipient" test number (Meta requires this for test mode) and verify it with the OTP they send.

### Step 3 — Set up the webhook (so the bot can *receive* messages)
Meta needs a public HTTPS URL to send incoming messages to — `localhost` won't work directly. For local testing, use a tunnel tool like [ngrok](https://ngrok.com/):

```bash
ngrok http 3000
```

This gives you a public URL like `https://abcd1234.ngrok-free.app`. Then:

1. In the Meta App dashboard → **WhatsApp → Configuration**.
2. Set **Callback URL** to: `https://abcd1234.ngrok-free.app/webhook`
3. Set **Verify Token** to the same value as `WHATSAPP_VERIFY_TOKEN` in your `.env` (default: `eliteffarena_verify_123`).
4. Click **Verify and Save** — if your server is running, it should succeed instantly (the route is already built in `whatsapp/webhook.js`).
5. Subscribe to the **messages** webhook field.

Once deployed to a real server (Section 6), replace the ngrok URL with your real domain's `/webhook` URL.

### Step 4 — Go from test mode to production (when ready for real players)
- Test mode only lets you message numbers you've manually added as testers — fine for development, **not enough for real tournaments**.
- To message *any* player's number:
  1. In Meta Business Suite, complete **Business Verification** for your business.
  2. Add and verify a **real phone number** (can be a new number you buy a SIM for, or in some cases your existing number — check Meta's number eligibility rules).
  3. Generate a **permanent access token** via a System User (Meta Business Settings → System Users → Generate Token), and put that in `WHATSAPP_TOKEN` instead of the temporary one.
  4. Update `WHATSAPP_PHONE_NUMBER_ID` to your verified number's ID.

### Step 5 — Set the number players send screenshots to
In `.env`, set:
```
TOURNAMENT_WHATSAPP_NUMBER=91XXXXXXXXXX
```
This is shown to players on the registration page. It should be the **same number** connected to your WhatsApp Cloud API setup, since that's the number the bot listens on.

---

## 5. How the payment verification flow actually works

1. Player fills the registration form on the website (team name, FF UIDs, **their own WhatsApp number**).
2. Player pays the entry fee via UPI (UPI ID shown on the registration page, from `UPI_ID` in `.env`).
3. Player sends a **screenshot of the payment** either:
   - directly on the website form (optional file upload), **or**
   - to your tournament WhatsApp number as a chat image.
4. If sent via WhatsApp, the bot automatically:
   - downloads the image,
   - matches it to that phone number's most recent pending registration,
   - marks the registration as `proof_submitted`,
   - replies confirming receipt.
5. You (admin) open **Admin → Tournaments → Registrations**, see the screenshot, and click **Approve** or **Reject**.
   - **Approve** → registration becomes `confirmed`, gets a slot number, and the player gets an automatic WhatsApp confirmation.
   - **Reject** → player gets a WhatsApp message with your reason, and can resend a clearer screenshot.
6. Closer to match time, you fill in **Room ID & Password** in the tournament's admin page → this is sent automatically via WhatsApp to every confirmed team.
7. After the match, enter results in the admin panel — they appear on the public leaderboard page.

**Note on automation level:** screenshot *matching* (linking an image to the right player) is automatic. Verifying that the screenshot is a *genuine, uncertain* payment is still a manual judgment call by you — this project deliberately does not auto-approve, since that would create real fraud risk with real money.

---

## 6. Deployment

Any standard Node.js host works (Railway, Render, a VPS, etc.). Quick checklist:

1. Set all `.env` values for production — especially a strong random `SESSION_SECRET`, your real `MONGODB_URI` (e.g. MongoDB Atlas), and production WhatsApp credentials.
2. Make sure `public/uploads/` is a **persistent** writable directory on your host (some platforms wipe local disk on redeploy — if so, consider swapping local file storage for something like an S3 bucket; ask if you want this added).
3. Point your WhatsApp webhook (Section 4, Step 3) to `https://yourdomain.com/webhook`.
4. Run `npm run seed-admin` once on the production database to create your admin login.
5. Start the app with `npm start` (use a process manager like `pm2` to keep it running, e.g. `pm2 start server.js`).

---

## 7. Project structure

```
eliteffarena/
├── server.js                 # app entrypoint
├── config/db.js              # MongoDB connection
├── models/                   # Tournament, Registration, Admin, WhatsappLog
├── routes/
│   ├── public.js             # homepage, listings, registration form
│   ├── adminAuth.js          # admin login/logout
│   └── admin.js               # admin CRUD + approval logic
├── whatsapp/
│   ├── whatsappService.js    # sending messages / downloading media via Cloud API
│   └── webhook.js            # receives incoming WhatsApp messages
├── middleware/
│   ├── auth.js                # admin session guard
│   └── upload.js               # multer file upload config
├── views/                     # EJS templates (public + admin/)
├── public/css/style.css       # all styling
├── public/uploads/            # payment proofs, banners (created automatically)
└── scripts/createAdmin.js     # one-time admin account creator
```

---

## 8. Customizing

- **Colors/branding**: edit the CSS variables at the top of `public/css/style.css` (`:root` block).
- **Site name**: currently "EliteFFArena" — change in `views/partials/header.ejs`, `views/partials/admin-header.ejs`, and `server.js` (`siteName` local).
- **Rules text / prize format**: edit per-tournament in the admin panel, or change the defaults in `views/admin/tournament-form.ejs`.

---

## 9. Known limitations / things to add later if needed

- No automatic payment gateway (Razorpay/Cashfree) — can be added later once you have business KYC; ask if you'd like this wired in.
- No email notifications — currently WhatsApp-only.
- No player-facing login/dashboard — players track status via WhatsApp messages only; could add a "check my registration status" page using phone number lookup if useful.
- File uploads are stored on local disk — fine for a single server, but won't survive redeploys on some hosting platforms (move to cloud storage if you scale up).

If you want any of these added, just ask.
