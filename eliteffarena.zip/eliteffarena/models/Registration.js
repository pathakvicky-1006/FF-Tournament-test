const mongoose = require('mongoose');

const teamMemberSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  ffUid: { type: String, required: true, trim: true }
});

const registrationSchema = new mongoose.Schema(
  {
    tournament: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Tournament',
      required: true
    },
    teamName: {
      type: String,
      required: true,
      trim: true
    },
    captainName: {
      type: String,
      required: true,
      trim: true
    },
    captainFfUid: {
      type: String,
      required: true,
      trim: true
    },
    whatsappNumber: {
      type: String,
      required: true,
      trim: true
      // store as country-code + number, e.g. 919999999999
    },
    teamMembers: [teamMemberSchema], // extra members besides captain (for duo/squad)

    // ---- Payment / verification flow ----
    paymentStatus: {
      type: String,
      enum: ['pending_proof', 'proof_submitted', 'verified', 'rejected'],
      default: 'pending_proof'
    },
    paymentProofUrl: {
      type: String, // path to uploaded screenshot, or WhatsApp media reference
      default: ''
    },
    paymentProofSource: {
      type: String,
      enum: ['website_upload', 'whatsapp'],
      default: 'website_upload'
    },
    transactionRefNote: {
      type: String, // optional UTR/txn id the player typed in
      default: ''
    },
    verifiedBy: {
      type: String, // admin username
      default: ''
    },
    verifiedAt: {
      type: Date
    },
    rejectionReason: {
      type: String,
      default: ''
    },

    // ---- Registration confirmation ----
    registrationStatus: {
      type: String,
      enum: ['pending', 'confirmed', 'rejected', 'cancelled'],
      default: 'pending'
    },
    slotNumber: {
      type: Number
    },
    whatsappNotified: {
      type: Boolean,
      default: false
    }
  },
  { timestamps: true }
);

registrationSchema.index({ tournament: 1, whatsappNumber: 1 });

module.exports = mongoose.model('Registration', registrationSchema);
