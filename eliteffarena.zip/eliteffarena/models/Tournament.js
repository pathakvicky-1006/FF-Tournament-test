const mongoose = require('mongoose');

const tournamentSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true
    },
    mode: {
      type: String,
      enum: ['Solo', 'Duo', 'Squad'],
      required: true
    },
    map: {
      type: String,
      default: 'Bermuda'
    },
    entryFee: {
      type: Number,
      required: true,
      min: 0
    },
    prizePool: {
      type: Number,
      required: true,
      min: 0
    },
    prizeBreakdown: {
      type: String, // free text e.g. "1st: ₹500, 2nd: ₹300, 3rd: ₹200, Most kills: ₹100"
      default: ''
    },
    maxSlots: {
      type: Number,
      required: true,
      min: 1
    },
    perTeamPlayers: {
      type: Number,
      default: 1 // 1 for solo, 2 for duo, 4 for squad
    },
    matchDate: {
      type: Date,
      required: true
    },
    registrationDeadline: {
      type: Date,
      required: true
    },
    roomId: {
      type: String,
      default: ''
    },
    roomPassword: {
      type: String,
      default: ''
    },
    roomPublishedAt: {
      type: Date
    },
    status: {
      type: String,
      enum: ['upcoming', 'registration_open', 'registration_closed', 'live', 'completed', 'cancelled'],
      default: 'registration_open'
    },
    rules: {
      type: String,
      default: 'Standard Free Fire tournament rules apply. No teaming, no hacking/cheating, no emulator (unless allowed). Disqualification on rule violation, no refund.'
    },
    bannerImage: {
      type: String,
      default: ''
    },
    results: [
      {
        position: Number,
        teamName: String,
        kills: Number,
        prizeWon: Number
      }
    ],
    createdAt: {
      type: Date,
      default: Date.now
    }
  },
  { timestamps: true }
);

// Virtual: slots filled (only counts confirmed registrations)
tournamentSchema.virtual('isFull').get(function () {
  return this.confirmedCount >= this.maxSlots;
});

module.exports = mongoose.model('Tournament', tournamentSchema);
