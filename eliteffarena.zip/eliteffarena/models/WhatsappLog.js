const mongoose = require('mongoose');

const whatsappLogSchema = new mongoose.Schema(
  {
    direction: {
      type: String,
      enum: ['incoming', 'outgoing'],
      required: true
    },
    fromNumber: { type: String },
    toNumber: { type: String },
    messageType: {
      type: String,
      enum: ['text', 'image', 'document', 'template', 'other'],
      default: 'text'
    },
    textBody: { type: String, default: '' },
    mediaId: { type: String, default: '' }, // WhatsApp media id (for images sent as proof)
    mediaLocalPath: { type: String, default: '' }, // after we download it
    relatedRegistration: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Registration'
    },
    rawPayload: { type: mongoose.Schema.Types.Mixed },
    matched: { type: Boolean, default: false } // whether we could link this msg to a registration
  },
  { timestamps: true }
);

module.exports = mongoose.model('WhatsappLog', whatsappLogSchema);
