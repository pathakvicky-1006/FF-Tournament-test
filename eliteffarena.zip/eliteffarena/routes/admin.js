const express = require('express');
const router = express.Router();
const Tournament = require('../models/Tournament');
const Registration = require('../models/Registration');
const WhatsappLog = require('../models/WhatsappLog');
const upload = require('../middleware/upload');
const { requireAdminAuth } = require('../middleware/auth');
const { sendTextMessage } = require('../whatsapp/whatsappService');

router.use(requireAdminAuth);

// ---------- DASHBOARD ----------
router.get('/dashboard', async (req, res) => {
  const totalTournaments = await Tournament.countDocuments();
  const openTournaments = await Tournament.countDocuments({ status: 'registration_open' });
  const pendingVerification = await Registration.countDocuments({ paymentStatus: 'proof_submitted' });
  const totalConfirmed = await Registration.countDocuments({ registrationStatus: 'confirmed' });

  const recentRegistrations = await Registration.find({ paymentStatus: 'proof_submitted' })
    .populate('tournament')
    .sort({ createdAt: -1 })
    .limit(10);

  res.render('admin/dashboard', {
    title: 'Admin Dashboard',
    stats: { totalTournaments, openTournaments, pendingVerification, totalConfirmed },
    recentRegistrations
  });
});

// ---------- TOURNAMENT LIST ----------
router.get('/tournaments', async (req, res) => {
  const tournaments = await Tournament.find().sort({ createdAt: -1 });
  res.render('admin/tournaments', { title: 'Manage Tournaments', tournaments });
});

// ---------- CREATE TOURNAMENT ----------
router.get('/tournaments/new', (req, res) => {
  res.render('admin/tournament-form', { title: 'New Tournament', tournament: null, errors: [] });
});

router.post('/tournaments/new', upload.single('bannerImage'), async (req, res) => {
  try {
    const t = req.body;
    await Tournament.create({
      title: t.title,
      mode: t.mode,
      map: t.map || 'Bermuda',
      entryFee: Number(t.entryFee),
      prizePool: Number(t.prizePool),
      prizeBreakdown: t.prizeBreakdown,
      maxSlots: Number(t.maxSlots),
      perTeamPlayers: t.mode === 'Solo' ? 1 : t.mode === 'Duo' ? 2 : 4,
      matchDate: new Date(t.matchDate),
      registrationDeadline: new Date(t.registrationDeadline),
      rules: t.rules,
      status: t.status || 'registration_open',
      bannerImage: req.file ? `/uploads/banners/${req.file.filename}` : ''
    });
    req.flash('success', 'Tournament created successfully.');
    res.redirect('/admin/tournaments');
  } catch (err) {
    console.error(err);
    res.render('admin/tournament-form', {
      title: 'New Tournament',
      tournament: req.body,
      errors: [{ msg: err.message }]
    });
  }
});

// ---------- EDIT TOURNAMENT ----------
router.get('/tournaments/:id/edit', async (req, res) => {
  const tournament = await Tournament.findById(req.params.id);
  if (!tournament) return res.status(404).send('Not found');
  res.render('admin/tournament-form', { title: 'Edit Tournament', tournament, errors: [] });
});

router.post('/tournaments/:id/edit', upload.single('bannerImage'), async (req, res) => {
  const t = req.body;
  const update = {
    title: t.title,
    mode: t.mode,
    map: t.map || 'Bermuda',
    entryFee: Number(t.entryFee),
    prizePool: Number(t.prizePool),
    prizeBreakdown: t.prizeBreakdown,
    maxSlots: Number(t.maxSlots),
    perTeamPlayers: t.mode === 'Solo' ? 1 : t.mode === 'Duo' ? 2 : 4,
    matchDate: new Date(t.matchDate),
    registrationDeadline: new Date(t.registrationDeadline),
    rules: t.rules,
    status: t.status
  };
  if (req.file) update.bannerImage = `/uploads/banners/${req.file.filename}`;

  await Tournament.findByIdAndUpdate(req.params.id, update);
  req.flash('success', 'Tournament updated.');
  res.redirect('/admin/tournaments');
});

// ---------- DELETE TOURNAMENT ----------
router.post('/tournaments/:id/delete', async (req, res) => {
  await Tournament.findByIdAndDelete(req.params.id);
  await Registration.deleteMany({ tournament: req.params.id });
  req.flash('success', 'Tournament deleted.');
  res.redirect('/admin/tournaments');
});

// ---------- PUBLISH ROOM ID/PASSWORD ----------
router.post('/tournaments/:id/publish-room', async (req, res) => {
  const tournament = await Tournament.findById(req.params.id);
  if (!tournament) return res.status(404).send('Not found');

  tournament.roomId = req.body.roomId;
  tournament.roomPassword = req.body.roomPassword;
  tournament.roomPublishedAt = new Date();
  tournament.status = 'live';
  await tournament.save();

  // Notify all confirmed players via WhatsApp
  const confirmed = await Registration.find({ tournament: tournament._id, registrationStatus: 'confirmed' });
  for (const reg of confirmed) {
    const msg =
      `🔥 Room details for *${tournament.title}*\n\n` +
      `Room ID: ${tournament.roomId}\nPassword: ${tournament.roomPassword}\n\n` +
      `Team: ${reg.teamName} — Slot #${reg.slotNumber || '-'}\nJoin on time. Good luck!`;
    await sendTextMessage(reg.whatsappNumber, msg).catch(() => {});
  }

  req.flash('success', `Room details published and sent to ${confirmed.length} confirmed teams.`);
  res.redirect(`/admin/tournaments/${tournament._id}/registrations`);
});

// ---------- SAVE RESULTS ----------
router.post('/tournaments/:id/results', async (req, res) => {
  const tournament = await Tournament.findById(req.params.id);
  if (!tournament) return res.status(404).send('Not found');

  const positions = Array.isArray(req.body.position) ? req.body.position : [req.body.position];
  const teamNames = Array.isArray(req.body.resultTeamName) ? req.body.resultTeamName : [req.body.resultTeamName];
  const kills = Array.isArray(req.body.kills) ? req.body.kills : [req.body.kills];
  const prizes = Array.isArray(req.body.prizeWon) ? req.body.prizeWon : [req.body.prizeWon];

  const results = positions
    .map((pos, i) => ({
      position: Number(pos),
      teamName: teamNames[i],
      kills: Number(kills[i] || 0),
      prizeWon: Number(prizes[i] || 0)
    }))
    .filter((r) => r.teamName);

  tournament.results = results;
  tournament.status = 'completed';
  await tournament.save();

  req.flash('success', 'Results saved and tournament marked completed.');
  res.redirect(`/admin/tournaments`);
});

// ---------- REGISTRATIONS FOR A TOURNAMENT ----------
router.get('/tournaments/:id/registrations', async (req, res) => {
  const tournament = await Tournament.findById(req.params.id);
  if (!tournament) return res.status(404).send('Not found');

  const filter = { tournament: tournament._id };
  if (req.query.status) filter.paymentStatus = req.query.status;

  const registrations = await Registration.find(filter).sort({ createdAt: -1 });

  res.render('admin/registrations', {
    title: `Registrations - ${tournament.title}`,
    tournament,
    registrations,
    query: req.query
  });
});

// ---------- APPROVE REGISTRATION ----------
router.post('/registrations/:id/approve', async (req, res) => {
  const registration = await Registration.findById(req.params.id).populate('tournament');
  if (!registration) return res.status(404).send('Not found');

  const confirmedCount = await Registration.countDocuments({
    tournament: registration.tournament._id,
    registrationStatus: 'confirmed'
  });
  if (confirmedCount >= registration.tournament.maxSlots) {
    req.flash('error', 'Cannot approve — tournament is already full.');
    return res.redirect(`/admin/tournaments/${registration.tournament._id}/registrations`);
  }

  registration.paymentStatus = 'verified';
  registration.registrationStatus = 'confirmed';
  registration.verifiedBy = req.session.adminUsername;
  registration.verifiedAt = new Date();
  registration.slotNumber = confirmedCount + 1;
  await registration.save();

  const msg =
    `✅ Payment verified! Team "${registration.teamName}" is *CONFIRMED* for *${registration.tournament.title}*.\n\n` +
    `Your slot number: #${registration.slotNumber}\n\n` +
    `Room ID & Password will be sent here closer to match time (${new Date(
      registration.tournament.matchDate
    ).toLocaleString('en-IN')}). Stay tuned!`;
  await sendTextMessage(registration.whatsappNumber, msg).catch(() => {});
  registration.whatsappNotified = true;
  await registration.save();

  req.flash('success', `Registration approved. Team confirmed at slot #${registration.slotNumber}.`);
  res.redirect(`/admin/tournaments/${registration.tournament._id}/registrations`);
});

// ---------- REJECT REGISTRATION ----------
router.post('/registrations/:id/reject', async (req, res) => {
  const registration = await Registration.findById(req.params.id).populate('tournament');
  if (!registration) return res.status(404).send('Not found');

  registration.paymentStatus = 'rejected';
  registration.registrationStatus = 'rejected';
  registration.rejectionReason = req.body.reason || 'Payment proof could not be verified.';
  registration.verifiedBy = req.session.adminUsername;
  registration.verifiedAt = new Date();
  await registration.save();

  const msg =
    `❌ We could not verify your payment for *${registration.tournament.title}* (Team: ${registration.teamName}).\n\n` +
    `Reason: ${registration.rejectionReason}\n\n` +
    `Please reply with a clearer screenshot/transaction proof, or contact support if you believe this is a mistake.`;
  await sendTextMessage(registration.whatsappNumber, msg).catch(() => {});

  req.flash('success', 'Registration rejected and player notified.');
  res.redirect(`/admin/tournaments/${registration.tournament._id}/registrations`);
});

// ---------- WHATSAPP LOGS (for debugging/audit) ----------
router.get('/whatsapp-logs', async (req, res) => {
  const logs = await WhatsappLog.find().sort({ createdAt: -1 }).limit(100).populate('relatedRegistration');
  res.render('admin/whatsapp-logs', { title: 'WhatsApp Logs', logs });
});

module.exports = router;
