const express = require('express');
const router = express.Router();
const Admin = require('../models/Admin');
const { redirectIfLoggedIn } = require('../middleware/auth');

router.get('/login', redirectIfLoggedIn, (req, res) => {
  res.render('admin/login', { title: 'Admin Login - EliteFFArena' });
});

router.post('/login', redirectIfLoggedIn, async (req, res) => {
  const { username, password } = req.body;
  try {
    const admin = await Admin.findOne({ username: username.trim() });
    if (!admin) {
      req.flash('error', 'Invalid username or password.');
      return res.redirect('/admin/login');
    }
    const match = await admin.comparePassword(password);
    if (!match) {
      req.flash('error', 'Invalid username or password.');
      return res.redirect('/admin/login');
    }
    req.session.adminId = admin._id;
    req.session.adminUsername = admin.username;
    req.session.adminRole = admin.role;
    res.redirect('/admin/dashboard');
  } catch (err) {
    console.error(err);
    req.flash('error', 'Something went wrong. Try again.');
    res.redirect('/admin/login');
  }
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/admin/login');
  });
});

module.exports = router;
