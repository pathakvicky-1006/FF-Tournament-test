const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Tournament = require('../models/Tournament');
const Registration = require('../models/Registration');
const upload = require('../middleware/upload');
const { sendTextMessage } = require('../whatsapp/whatsappService');

// ---------- HOME ----------
router.get('/', async (req, res) => {
  const tournaments = await Tournament.find({
    status: { $in: ['registration_open', 'upcoming', 'live'] }
  })
    .sort({ matchDate: 1 })
    .limit(6);

  // attach confirmed-slot counts
  const tournamentsWithCounts = await attachSlotCounts(tournaments);

  res.render('index', {
    title: 'EliteFFArena - Free Fire Tournaments',
    tournaments: tournamentsWithCounts
  });
});

// ---------- ALL TOURNAMENTS ----------
router.get('/tournaments', async (req, res) => {
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.mode) filter.mode = req.query.mode;

  const tournaments = await Tournament.find(filter).sort({ matchDate: 1 });
  const tournamentsWithCounts = await attachSlotCounts(tournaments);

  res.render('tournaments', {
    title: 'All Tournaments - EliteFFArena',
    tournaments: tournamentsWithCounts,
    query: req.query
  });
});

// ---------- TOURNAMENT DETAIL ----------
router.get('/tournaments/:id', async (req, res) => {
  const tournament = await Tournament.findById(req.params.id);
  if (!tournament) return res.status(404).render('404', { title: 'Not Found' });

  const confirmedCount = await Registration.countDocuments({
    tournament: tournament._id,
    registrationStatus: 'confirmed'
  });

  res.render('tournament-detail', {
    title: `${tournament.title} - EliteFFArena`,
    tournament,
    confirmedCount,
    slotsLeft: Math.max(tournament.maxSlots - confirmedCount, 0)
  });
});

// ---------- REGISTRATION FORM (GET) ----------
router.get('/tournaments/:id/register', async (req, res) => {
  const tournament = await Tournament.findById(req.params.id);
  if (!tournament) return res.status(404).render('404', { title: 'Not Found' });

  const confirmedCount = await Registration.countDocuments({
    tournament: tournament._id,
    registrationStatus: 'confirmed'
  });

  if (confirmedCount >= tournament.maxSlots) {
    return res.render('registration-closed', {
      title: 'Registration Closed - EliteFFArena',
      tournament,
      reason: 'full'
    });
  }
  if (new Date() > new Date(tournament.registrationDeadline)) {
    return res.render('registration-closed', {
      title: 'Registration Closed - EliteFFArena',
      tournament,
      reason: 'deadline'
    });
  }

  res.render('register', {
    title: `Register - ${tournament.title}`,
    tournament,
    errors: [],
    formData: {}
  });
});

// ---------- REGISTRATION FORM (POST) ----------
router.post(
  '/tournaments/:id/register',
  upload.single('paymentProof'),
  [
    body('teamName').trim().notEmpty().withMessage('Team name is required'),
    body('captainName').trim().notEmpty().withMessage('Captain name is required'),
    body('captainFfUid').trim().notEmpty().withMessage('Your Free Fire UID is required'),
    body('whatsappNumber')
      .trim()
      .matches(/^[0-9]{10,15}$/)
      .withMessage('Enter a valid WhatsApp number with country code, digits only (e.g. 919999999999)')
  ],
  async (req, res) => {
    const tournament = await Tournament.findById(req.params.id);
    if (!tournament) return res.status(404).render('404', { title: 'Not Found' });

    const errors = validationResult(req);

    const confirmedCount = await Registration.countDocuments({
      tournament: tournament._id,
      registrationStatus: 'confirmed'
    });
    if (confirmedCount >= tournament.maxSlots) {
      return res.render('registration-closed', { title: 'Registration Closed', tournament, reason: 'full' });
    }

    if (!errors.isEmpty()) {
      return res.render('register', {
        title: `Register - ${tournament.title}`,
        tournament,
        errors: errors.array(),
        formData: req.body
      });
    }

    // Parse extra team members for duo/squad (sent as teamMemberName[] / teamMemberUid[])
    let teamMembers = [];
    if (req.body.teamMemberName) {
      const names = Array.isArray(req.body.teamMemberName) ? req.body.teamMemberName : [req.body.teamMemberName];
      const uids = Array.isArray(req.body.teamMemberUid) ? req.body.teamMemberUid : [req.body.teamMemberUid];
      teamMembers = names
        .map((name, i) => ({ name: (name || '').trim(), ffUid: (uids[i] || '').trim() }))
        .filter((m) => m.name && m.ffUid);
    }

    const registration = await Registration.create({
      tournament: tournament._id,
      teamName: req.body.teamName.trim(),
      captainName: req.body.captainName.trim(),
      captainFfUid: req.body.captainFfUid.trim(),
      whatsappNumber: req.body.whatsappNumber.trim(),
      teamMembers,
      paymentProofUrl: req.file ? `/uploads/payment-proofs/${req.file.filename}` : '',
      paymentProofSource: 'website_upload',
      paymentStatus: req.file ? 'proof_submitted' : 'pending_proof',
      transactionRefNote: (req.body.transactionRefNote || '').trim()
    });

    // Send a WhatsApp message guiding them on next steps (best-effort; ignore failure)
    const upiId = process.env.UPI_ID || 'yourupi@bank';
    const tournamentNumber = process.env.TOURNAMENT_WHATSAPP_NUMBER || '';
    let waMessage = `🎮 Thanks for registering Team "${registration.teamName}" for *${tournament.title}* on EliteFFArena!\n\n` +
      `Entry Fee: ₹${tournament.entryFee}\nUPI ID: ${upiId}\n\n`;
    if (req.file) {
      waMessage += 'We see you already uploaded a payment screenshot on the website. Our team will verify it shortly.';
    } else {
      waMessage += `Please pay the entry fee and send a screenshot of the payment to this WhatsApp number to confirm your slot.`;
    }
    await sendTextMessage(registration.whatsappNumber, waMessage).catch(() => {});

    res.render('registration-success', {
      title: 'Registration Submitted - EliteFFArena',
      tournament,
      registration
    });
  }
);

// ---------- LEADERBOARD / RESULTS ----------
router.get('/leaderboard/:id', async (req, res) => {
  const tournament = await Tournament.findById(req.params.id);
  if (!tournament) return res.status(404).render('404', { title: 'Not Found' });

  res.render('leaderboard', {
    title: `Results - ${tournament.title}`,
    tournament
  });
});

// Helper: attach confirmed count + slotsLeft to a list of tournaments
async function attachSlotCounts(tournaments) {
  const results = [];
  for (const t of tournaments) {
    const confirmedCount = await Registration.countDocuments({
      tournament: t._id,
      registrationStatus: 'confirmed'
    });
    results.push({
      ...t.toObject(),
      confirmedCount,
      slotsLeft: Math.max(t.maxSlots - confirmedCount, 0)
    });
  }
  return results;
}

module.exports = router;
