require('dotenv').config();
const mongoose = require('mongoose');
const Admin = require('../models/Admin');

async function run() {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/eliteffarena');

  const username = process.env.ADMIN_USERNAME || 'admin';
  const password = process.env.ADMIN_PASSWORD || 'ChangeThisPassword123!';

  const existing = await Admin.findOne({ username });
  if (existing) {
    console.log(`Admin "${username}" already exists. Skipping.`);
    process.exit(0);
  }

  const passwordHash = await Admin.hashPassword(password);
  await Admin.create({ username, passwordHash, role: 'superadmin' });

  console.log(`✅ Admin created -> username: ${username} | password: ${password}`);
  console.log('Login at /admin/login and change this password setup if needed.');
  process.exit(0);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
