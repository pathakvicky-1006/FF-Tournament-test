require('dotenv').config();
const express = require('express');
const path = require('path');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const flash = require('connect-flash');
const morgan = require('morgan');
const methodOverride = require('method-override');

const connectDB = require('./config/db');

const publicRoutes = require('./routes/public');
const adminAuthRoutes = require('./routes/adminAuth');
const adminRoutes = require('./routes/admin');
const whatsappWebhook = require('./whatsapp/webhook');

const app = express();
const PORT = process.env.PORT || 3000;

connectDB();

// ---------- VIEW ENGINE ----------
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ---------- MIDDLEWARE ----------
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json()); // needed for WhatsApp webhook JSON payloads
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(
  session({
    secret: process.env.SESSION_SECRET || 'dev_secret_change_me',
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
      mongoUrl: process.env.MONGODB_URI || 'mongodb://localhost:27017/eliteffarena'
    }),
    cookie: { maxAge: 1000 * 60 * 60 * 8 } // 8 hours
  })
);
app.use(flash());

// make flash messages + current admin available in all views
app.use((req, res, next) => {
  res.locals.success = req.flash('success');
  res.locals.error = req.flash('error');
  res.locals.isAdminLoggedIn = !!(req.session && req.session.adminId);
  res.locals.adminUsername = req.session ? req.session.adminUsername : null;
  res.locals.siteName = 'EliteFFArena';
  next();
});

// ---------- ROUTES ----------
app.use('/', publicRoutes);
app.use('/admin', adminAuthRoutes);
app.use('/admin', adminRoutes);
app.use('/', whatsappWebhook); // exposes /webhook (GET verify + POST receive)

// ---------- 404 ----------
app.use((req, res) => {
  res.status(404).render('404', { title: 'Page Not Found' });
});

// ---------- ERROR HANDLER ----------
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('500', { title: 'Server Error', error: process.env.NODE_ENV === 'development' ? err : null });
});

app.listen(PORT, () => {
  console.log(`🚀 EliteFFArena server running on http://localhost:${PORT}`);
});
