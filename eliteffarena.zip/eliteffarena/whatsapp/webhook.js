const express = require('express');
const router = express.Router();
const path = require('path');
const Registration = require('../models/Registration');
const WhatsappLog = require('../models/WhatsappLog');
const { sendTextMessage, downloadMedia } = require('./whatsappService');

const PROOFS_DIR = path.join(__dirname, '..', 'public', 'uploads', 'whatsapp-proofs');

/**
 * GET /webhook -> used by Meta to verify the webhook URL when you set it up
 * in the Meta Developer dashboard (App > WhatsApp > Configuration).
 */
router.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    console.log('✅ WhatsApp webhook verified');
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

/**
 * POST /webhook -> Meta sends every incoming message/status update here.
 *
 * Flow implemented:
 * 1. Player has already registered on the website with their WhatsApp number.
 * 2. Player sends a payment screenshot (image) to the tournament WhatsApp number.
 * 3. We find their most recent "pending_proof" registration that matches the
 *    sender's number, download the image, attach it, and flip status to
 *    "proof_submitted".
 * 4. Admin sees it in the admin panel and approves/rejects manually
 *    (see routes/admin.js). On approval, a confirmation message + room
 *    details are sent back automatically via this same WhatsApp number.
 */
router.post('/webhook', async (req, res) => {
  // Always 200 immediately - Meta retries aggressively if you don't ack fast
  res.sendStatus(200);

  try {
    const entry = req.body.entry && req.body.entry[0];
    const change = entry && entry.changes && entry.changes[0];
    const value = change && change.value;
    if (!value || !value.messages) return; // status update or non-message event, ignore

    const message = value.messages[0];
    const fromNumber = message.from; // e.g. "919999999999"

    if (message.type === 'image') {
      await handleIncomingImage(message, fromNumber);
    } else if (message.type === 'text') {
      await handleIncomingText(message, fromNumber);
    } else {
      await WhatsappLog.create({
        direction: 'incoming',
        fromNumber,
        messageType: 'other',
        rawPayload: message
      });
    }
  } catch (err) {
    console.error('Webhook processing error:', err);
  }
});

async function findLatestPendingRegistration(fromNumber) {
  return Registration.findOne({
    whatsappNumber: fromNumber,
    paymentStatus: { $in: ['pending_proof', 'proof_submitted'] }
  })
    .sort({ createdAt: -1 })
    .populate('tournament');
}

async function handleIncomingImage(message, fromNumber) {
  const mediaId = message.image.id;

  const downloadResult = await downloadMedia(mediaId, PROOFS_DIR);

  const registration = await findLatestPendingRegistration(fromNumber);

  const log = await WhatsappLog.create({
    direction: 'incoming',
    fromNumber,
    messageType: 'image',
    mediaId,
    mediaLocalPath: downloadResult.success ? downloadResult.fullPath : '',
    relatedRegistration: registration ? registration._id : undefined,
    matched: !!registration,
    rawPayload: message
  });

  if (!registration) {
    // Couldn't auto-match — tell the player to register first / contact support
    await sendTextMessage(
      fromNumber,
      "We received your image, but we couldn't find a matching pending registration for this number. " +
        'Please make sure you registered on the website with this exact WhatsApp number, then resend your payment screenshot. ' +
        'If you need help, reply here and our team will check manually.'
    );
    return;
  }

  if (downloadResult.success) {
    registration.paymentProofUrl = `/uploads/whatsapp-proofs/${downloadResult.fileName}`;
    registration.paymentProofSource = 'whatsapp';
  }
  registration.paymentStatus = 'proof_submitted';
  await registration.save();

  await sendTextMessage(
    fromNumber,
    `✅ Got your payment screenshot for *${registration.tournament.title}* (Team: ${registration.teamName}). ` +
      'Our team will verify it shortly and you will receive a confirmation message here once approved. ' +
      'Thanks for registering with EliteFFArena!'
  );
}

async function handleIncomingText(message, fromNumber) {
  const text = message.text.body.trim();

  const registration = await findLatestPendingRegistration(fromNumber);

  await WhatsappLog.create({
    direction: 'incoming',
    fromNumber,
    messageType: 'text',
    textBody: text,
    relatedRegistration: registration ? registration._id : undefined,
    matched: !!registration,
    rawPayload: message
  });

  // If they typed a transaction ID / UTR number along with their proof, save it as a note
  if (registration && /^[A-Za-z0-9]{6,}$/.test(text.replace(/\s/g, ''))) {
    registration.transactionRefNote = text;
    await registration.save();
    await sendTextMessage(
      fromNumber,
      'Noted your transaction reference. If you haven\'t sent the payment screenshot yet, please send it now so we can verify and confirm your slot.'
    );
    return;
  }

  // Generic auto-reply
  await sendTextMessage(
    fromNumber,
    'Hi! This is the EliteFFArena tournament bot. Please send your *payment screenshot* here after registering on the website, ' +
      'and our team will verify and confirm your slot. For other queries, our support team will reply soon.'
  );
}

module.exports = router;
