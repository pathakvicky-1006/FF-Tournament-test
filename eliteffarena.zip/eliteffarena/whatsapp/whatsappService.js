const axios = require('axios');
const fs = require('fs');
const path = require('path');

const GRAPH_VERSION = 'v20.0';
const TOKEN = () => process.env.WHATSAPP_TOKEN;
const PHONE_NUMBER_ID = () => process.env.WHATSAPP_PHONE_NUMBER_ID;

function graphUrl(pathSuffix) {
  return `https://graph.facebook.com/${GRAPH_VERSION}/${pathSuffix}`;
}

/**
 * Send a plain text message via WhatsApp Cloud API
 */
async function sendTextMessage(toNumber, body) {
  try {
    const url = graphUrl(`${PHONE_NUMBER_ID()}/messages`);
    const res = await axios.post(
      url,
      {
        messaging_product: 'whatsapp',
        to: toNumber,
        type: 'text',
        text: { body }
      },
      { headers: { Authorization: `Bearer ${TOKEN()}` } }
    );
    return { success: true, data: res.data };
  } catch (err) {
    console.error('WhatsApp sendTextMessage error:', err.response ? err.response.data : err.message);
    return { success: false, error: err.response ? err.response.data : err.message };
  }
}

/**
 * Download media (e.g. payment screenshot) sent by a user.
 * WhatsApp gives us a media ID -> we fetch its temporary URL -> download bytes.
 */
async function downloadMedia(mediaId, saveDir) {
  try {
    const metaRes = await axios.get(graphUrl(mediaId), {
      headers: { Authorization: `Bearer ${TOKEN()}` }
    });
    const mediaUrl = metaRes.data.url;
    const mimeType = metaRes.data.mime_type || 'image/jpeg';
    const ext = mimeType.split('/')[1] || 'jpg';

    const fileRes = await axios.get(mediaUrl, {
      headers: { Authorization: `Bearer ${TOKEN()}` },
      responseType: 'arraybuffer'
    });

    if (!fs.existsSync(saveDir)) {
      fs.mkdirSync(saveDir, { recursive: true });
    }

    const fileName = `wa_${mediaId}.${ext}`;
    const fullPath = path.join(saveDir, fileName);
    fs.writeFileSync(fullPath, fileRes.data);

    return { success: true, fileName, fullPath };
  } catch (err) {
    console.error('WhatsApp downloadMedia error:', err.response ? err.response.data : err.message);
    return { success: false, error: err.response ? err.response.data : err.message };
  }
}

module.exports = {
  sendTextMessage,
  downloadMedia
};
